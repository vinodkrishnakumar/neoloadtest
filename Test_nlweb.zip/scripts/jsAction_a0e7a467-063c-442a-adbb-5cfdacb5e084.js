﻿// Get variable value from VariableManager
var businessPartner = context.variableManager.getValue("nekupo_businesspt");
if (businessPartner == null) {
    context.fail("Variable 'nekupo_businesspt' not found");
}

//var computedValue = myLibraryFunction(myVar);
//logger.debug("ComputedValue="+computedValue);
var obj = JSON.parse(businessPartner);
var nekupo_email = obj.ZZ_INFO_EMAIL;
var nekupo_partner = obj.PARTNER;


function getAnlage(businessPartner) {
    var nekupo_active_anlage = [];
    for (var i = 0; i < businessPartner.VKONT_TAB.length; i++) {
        var vkont_tab = obj.VKONT_TAB[i];
        if (vkont_tab.hasOwnProperty("IS_ACTIVE") && vkont_tab.hasOwnProperty("ANLAGEN_TAB")) {
            if (vkont_tab.IS_ACTIVE == true) {
                for (var j = 0; j < vkont_tab.ANLAGEN_TAB.length; j++) {
                    var anlagen_tag = vkont_tab.ANLAGEN_TAB[j];
                    if (anlagen_tag.hasOwnProperty("ACTIVE") && anlagen_tag.hasOwnProperty("ANLAGE")) {
                        if (anlagen_tag.ACTIVE == true) {
                            nekupo_active_anlage.push(anlagen_tag.ANLAGE);
                        }
                    }
                }
            }
        }
    }
    return nekupo_active_anlage;
}

var activeAnlage = getAnlage(obj);

// Inject the computed value in a runtime variable
context.variableManager.setValue("nekupo_email", nekupo_email);
context.variableManager.setValue("nekupo_partner", nekupo_partner);
context.variableManager.setValue("nekupo_activeAnlage", JSON.stringify(activeAnlage));